//
//  CalculatorViewController.swift
//  Course2Week3Task1
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class CalculatorViewController: UIViewController {

    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var firstOperandLabel: UILabel!
    @IBOutlet weak var stepperFirstOperand: UIStepper!
    @IBOutlet weak var secondOperandLabel: UILabel!
    @IBOutlet weak var sliderSecondOperand: UISlider!
    let colorMain = UIColor(red: 0.925, green:  0.443, blue: 0.286, alpha: 1).cgColor
    let numberformatter = NumberFormatter()


    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        numberformatter.minimumFractionDigits = 4
        stepperFirstOperand.setDecrementImage(stepperFirstOperand.decrementImage(for: .normal), for: .normal)
        stepperFirstOperand.setIncrementImage(stepperFirstOperand.incrementImage(for: .normal), for: .normal)
        
        stepperFirstOperand.layer.cornerRadius = 4
        stepperFirstOperand.layer.borderWidth = 1
        stepperFirstOperand.layer.borderColor = colorMain
        stepperFirstOperand.tintColor = UIColor(red: 0.925, green:  0.443, blue: 0.286, alpha: 1)
        resultLabel.text = "1"
        
        firstOperandLabel.text = numberformatter.string(from: NSNumber(value: stepperFirstOperand!.value))
        
        secondOperandLabel.text = numberformatter.string(from: NSNumber(value: sliderSecondOperand!.value))
    }
    
    @IBAction func getFirstOperand(_ sender: UIStepper) {
        firstOperandLabel.text = numberformatter.string(from: NSNumber(value: stepperFirstOperand!.value))
    }
    
    
    @IBAction func getSecondOperand(_ sender: UISlider) {
        secondOperandLabel.text = numberformatter.string(from: NSNumber(value: sliderSecondOperand!.value))
    }
    
    
    @IBAction func getResult(_ sender: UIButton) {
        
        // Можно упростить, не создавать переменные. Но я оставлю, чтоб было понятно, что делаю
        let a = sliderSecondOperand.value
        let b = Float(stepperFirstOperand.value)
        var bufferResult = numberformatter.string(from: NSNumber(value: a * b))
        
        //Пропускаем через фильтр нулей
        while bufferResult!.last == "0" || bufferResult!.last == "." { bufferResult!.popLast() }
        
        resultLabel.text = bufferResult
        
    }
    
}
